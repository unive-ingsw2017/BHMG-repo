package it.unive.dais.cevid.datadroid.template;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.webkit.WebView;
import android.widget.Toast;
import android.webkit.WebViewClient;

public class NavigationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_navigation);
        String l = (String)getIntent().getStringExtra("ID");
        String o = (String)getIntent().getStringExtra("LEL");
        String pv = (String)getIntent().getStringExtra("PR");
        WebView w = (WebView)findViewById(R.id.lol);
        WebView mWebview ;
        mWebview  = new WebView(this);
        mWebview.getSettings().setJavaScriptEnabled(true); // enable javascript
        final Activity activity = this;

        mWebview.setWebViewClient(new WebViewClient() {
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                Toast.makeText(activity, description, Toast.LENGTH_SHORT).show();
            }
        });

        mWebview .loadUrl("http://www.irvv.net/nc/it/ville-aperte.html?villaId="+o);
        setContentView(mWebview );
    }
}