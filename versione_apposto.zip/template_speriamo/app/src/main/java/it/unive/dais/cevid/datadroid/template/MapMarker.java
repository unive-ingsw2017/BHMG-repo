package it.unive.dais.cevid.datadroid.template;

/**
 * Created by nikitabaldan on 08/01/18.
 */

        import com.google.android.gms.maps.model.LatLng;
        import com.google.maps.android.clustering.ClusterItem;
        import java.io.IOException;
        import java.io.ObjectInputStream;
        import java.io.ObjectOutputStream;
        import java.io.Serializable;

        import it.unive.dais.cevid.datadroid.lib.util.MapItem;

public class MapMarker extends MapItem implements ClusterItem, Serializable {
    private double lat;
    private double lng;
    private String title;
    private String snippet;
    private String lel;
    private String prov;

    public MapMarker(double lat, double lng) {
        this.lat = lat;
        this.lng = lng;
        title = "";
        snippet = "";
        lel = "";
        prov = "";
    }

    public MapMarker(double lat, double lng, String title, String snippet, String lel, String prov) {
        this.lat = lat;
        this.lng = lng;
        this.title = title;
        this.snippet = snippet;
        this.lel = lel;
        this.prov = prov;
    }

    @Override
    public LatLng getPosition() {
        return new LatLng(lat, lng);
    }

    @Override
    public String getTitle() { return title; }

    @Override
    public String getSnippet() { return snippet; }

    /**
     * Set the title of the marker
     * @param title string to be set as title
     */
    public void setTitle(String title) {this.title = title;
    }

    /**
     * Set the description of the marker
     * @param snippet string to be set as snippet
     */
    public void setSnippet(String snippet) {
        this.snippet = snippet;
    }
    public String getLel(){return lel;}

    public void setLel(String lel) {
        this.lel = lel;
    }

    public String getProv(){return prov;}

    public void setProv(String prov) {
        this.prov = prov;
    }

}