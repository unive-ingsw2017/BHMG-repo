package it.unive.dais.cevid.datadroid.template;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.webkit.WebView;
import android.widget.Toast;
import android.webkit.WebViewClient;

public class NavigationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_navigation);
        String l = (String)getIntent().getStringExtra("ID");
        String m = (String)getIntent().getStringExtra("Snippet");
        WebView w = (WebView)findViewById(R.id.lol);
        WebView mWebview ;
        mWebview  = new WebView(this);
        mWebview.getSettings().setJavaScriptEnabled(true); // enable javascript
        final Activity activity = this;

        mWebview.setWebViewClient(new WebViewClient() {
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                Toast.makeText(activity, description, Toast.LENGTH_SHORT).show();
            }
        });

        mWebview .loadUrl("https://www.google.it/search?q="+l+" "+m);

        setContentView(mWebview );
    }
}
